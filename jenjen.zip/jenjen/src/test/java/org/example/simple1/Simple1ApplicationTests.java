package org.example.simple1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Simple1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
