package org.example.simple1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Simple1Application {

    public static void main(String[] args) {
        SpringApplication.run(Simple1Application.class, args);
    }

}
